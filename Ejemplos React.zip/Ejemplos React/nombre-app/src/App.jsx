function App(){
  return (
    <div>
  <h1>5C DSM</h1>
  <h2>TI Pablo Martinez Gaspar</h2>
  </div>
)
}

export default App
